package main

import (
	"encoding/binary"
	"fmt"
	"net"
	"os"
	"os/signal"
	"syscall"
)

const socketPath = "/tmp/dpe-emu.socket"

func main() {
	// Remove the socket file if it already exists
	os.Remove(socketPath)

	// Create a Unix domain socket listener
	listener, err := net.Listen("unix", socketPath)
	if err != nil {
		fmt.Println("Failed to create socket:", err)
		return
	}
	defer listener.Close()

	fmt.Println("Emulator is listening on", socketPath)

	// Handle graceful shutdown on SIGINT or SIGTERM
	signalChan := make(chan os.Signal, 1)
	signal.Notify(signalChan, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-signalChan
		listener.Close()
		os.Remove(socketPath)
		fmt.Println("Emulator stopped.")
		os.Exit(0)
	}()

	// Accept incoming connections and process commands
	for {
		conn, err := listener.Accept()
		if err != nil {
			fmt.Println("Error accepting connection:", err)
			continue
		}
		go handleConnection(conn)
	}
}

func handleConnection(conn net.Conn) {
	defer conn.Close()

	buf := make([]byte, 4) // Read the locality from the first 4 bytes
	_, err := conn.Read(buf)
	if err != nil {
		fmt.Println("Error reading locality:", err)
		return
	}
	locality := binary.LittleEndian.Uint32(buf)

	// Sample response message
	response := []byte("Emulator response for locality: ")
	response = append(response, []byte(fmt.Sprintf("%d", locality))...)

	_, err = conn.Write(response)
	if err != nil {
		fmt.Println("Error writing response:", err)
	}
}

